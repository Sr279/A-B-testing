# Week 3: A/B Testing Report

## 1. Business question
An online shop tested a **new checkout button (Variant B)** against the current one **(Variant A)**.
Does B increase the purchase conversion rate?

## 2. Data
* File: `data/ab_test_data.csv` (10,000 users: 5,000 per variant)
* Columns: `user_id`, `variant` (A/B), `converted` (1 = purchased, 0 = did not)
* Data is simulated with a fixed seed (`data/generate_data.py`), so it is reproducible.

## 3. Method
| Step | What was done |
|------|---------------|
| Hypotheses | H0: conversion(A) = conversion(B). H1: they differ (two-sided) |
| Test | Two-proportion z-test (pooled standard error), alpha = 0.05 |
| Confidence interval | 95% CI for the difference (B - A), unpooled standard error |
| Relative lift CI | Delta method on log(pB / pA) |
| Per-group CI | Wilson score interval |
| Sanity check | Sample Ratio Mismatch (chi-square on the 50/50 split) |
| Power | Users per group needed to detect a +1 pp lift at 80% power |

## 4. Results
| | Variant A | Variant B |
|---|---|---|
| Users | 5,000 | 5,000 |
| Conversions | 493 | 559 |
| Conversion rate | 9.86% | 11.18% |
| 95% CI (Wilson) | [9.06%, 10.72%] | [10.34%, 12.08%] |

| Metric | Value |
|---|---|
| Absolute difference (B - A) | **+1.32 percentage points** |
| 95% CI for difference | **[+0.12, +2.52] pp** |
| Relative lift | +13.4% (95% CI [+1.1%, +27.2%]) |
| z statistic | 2.151 |
| p-value | 0.0315 |
| Sample ratio check | p = 1.000 (split is healthy) |

![chart](outputs/ab_test_chart.png)

## 5. Conclusion
Variant B converts better than Variant A. The difference is **+1.32 percentage points
(95% CI: +0.12 to +2.52 pp, p = 0.0315)**. The confidence interval does **not** include 0
and p < 0.05, so the result is statistically significant at the 5% level.

**Recommendation:** roll out Variant B.

## 6. Caveats (be honest about limits)
* The CI is wide: the true gain could be as small as +0.12 pp or as large as +2.52 pp.
  The result is significant but only just (p = 0.03), so the effect size is uncertain.
* With the observed baseline (~9.9%), detecting a +1 pp lift reliably needs about
  **14,575 users per group**; this test had 5,000, so it is under-powered for effects that small.
  A longer test would narrow the interval.
* "Significant" does not mean "large". Check whether +0.1 to +2.5 pp is worth the cost of the change.
* One metric was tested, with no peeking and no multiple comparisons, so no correction is needed.
  Testing several metrics or looking early would need adjustment.
* Data is simulated; in a real test also check for novelty effects, seasonality and bots.
