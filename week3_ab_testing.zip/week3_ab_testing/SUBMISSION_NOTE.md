# Submission note: Week 3 A/B testing

**What I built:** A small Python project that analyses a sample A/B test (5,000 users per
variant), computes conversion rates, a z-test, 95% confidence intervals (difference,
relative lift, per-group), a sample-ratio check and a power calculation, and writes a
chart, a JSON result and a written report.

**Conclusion:** Variant B beat A by +1.32 percentage points (95% CI +0.12 to +2.52, p = 0.0315),
so B is significantly better, though the interval is wide.

**What I learned:**
* A p-value only says whether an effect is likely real; the confidence interval says how big it might be.
* Use the pooled standard error for the test and the unpooled one for the CI.
* Always run a sample-ratio check and think about power before trusting a result.
* A result can be "significant" and still be uncertain in size.

**Testing:** 11 pytest tests (normal cases and failure cases such as zero users, bad alpha,
more conversions than users).
