"""Create the sample A/B test dataset (data/ab_test_data.csv).

Fixed random seed => the file is reproducible.
Scenario: an online shop tests a new checkout button (variant B)
against the current one (variant A). Metric = purchase conversion.
"""
from pathlib import Path

import numpy as np
import pandas as pd

SEED = 42
N_PER_GROUP = 5000
TRUE_RATE_A = 0.10
TRUE_RATE_B = 0.115   # real lift of +1.5 percentage points


def make_data() -> pd.DataFrame:
    rng = np.random.default_rng(SEED)
    a = rng.binomial(1, TRUE_RATE_A, N_PER_GROUP)
    b = rng.binomial(1, TRUE_RATE_B, N_PER_GROUP)
    df = pd.DataFrame({
        "user_id": np.arange(1, 2 * N_PER_GROUP + 1),
        "variant": ["A"] * N_PER_GROUP + ["B"] * N_PER_GROUP,
        "converted": np.concatenate([a, b]),
    })
    return df.sample(frac=1, random_state=SEED).reset_index(drop=True)


if __name__ == "__main__":
    out = Path(__file__).parent / "ab_test_data.csv"
    make_data().to_csv(out, index=False)
    print(f"Wrote {out}")
