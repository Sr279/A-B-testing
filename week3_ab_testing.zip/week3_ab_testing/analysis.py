"""Run the full A/B analysis: python analysis.py [path/to/data.csv]"""
import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

from src.ab_test import (interpret, sample_size_per_group, srm_check,
                         two_proportion_ztest, wilson_ci)

ROOT = Path(__file__).parent
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)


def load(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    missing = {"user_id", "variant", "converted"} - set(df.columns)
    if missing:
        raise ValueError(f"CSV is missing columns: {missing}")
    if df["user_id"].duplicated().any():
        raise ValueError("Duplicate user_id found: a user appears more than once")
    if not df["converted"].isin([0, 1]).all():
        raise ValueError("'converted' must contain only 0 or 1")
    if set(df["variant"]) != {"A", "B"}:
        raise ValueError("'variant' must contain exactly A and B")
    return df


def plot(res, ci_a, ci_b) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(10, 4))

    ax = axes[0]
    rates = [res.rate_a * 100, res.rate_b * 100]
    errs = [[(res.rate_a - ci_a[0]) * 100, (res.rate_b - ci_b[0]) * 100],
            [(ci_a[1] - res.rate_a) * 100, (ci_b[1] - res.rate_b) * 100]]
    ax.bar(["A (control)", "B (variant)"], rates, yerr=errs, capsize=8,
           color=["#9aa5b1", "#2f80ed"])
    ax.set_ylabel("Conversion rate (%)")
    ax.set_title("Conversion rate with 95% CI")

    ax = axes[1]
    d, lo, hi = res.abs_diff * 100, res.diff_ci_low * 100, res.diff_ci_high * 100
    ax.errorbar([d], [0], xerr=[[d - lo], [hi - d]], fmt="o", capsize=8,
                color="#2f80ed", markersize=9)
    ax.axvline(0, color="red", linestyle="--", label="No difference")
    ax.set_yticks([])
    ax.set_xlabel("Difference B - A (percentage points)")
    ax.set_title("95% CI for the difference")
    ax.legend()

    fig.tight_layout()
    fig.savefig(OUT / "ab_test_chart.png", dpi=150)
    plt.close(fig)


def main(csv_path: Path) -> None:
    df = load(csv_path)
    g = df.groupby("variant")["converted"].agg(["sum", "count"])
    n_a, c_a = int(g.loc["A", "count"]), int(g.loc["A", "sum"])
    n_b, c_b = int(g.loc["B", "count"]), int(g.loc["B", "sum"])

    res = two_proportion_ztest(c_a, n_a, c_b, n_b, alpha=0.05)
    ci_a, ci_b = wilson_ci(c_a, n_a), wilson_ci(c_b, n_b)
    srm_p = srm_check(n_a, n_b)
    needed = sample_size_per_group(baseline=res.rate_a, mde_abs=0.01)

    summary = {
        **res.to_dict(),
        "ci_a": ci_a, "ci_b": ci_b,
        "srm_p_value": srm_p,
        "srm_ok": srm_p >= 0.001,
        "n_needed_per_group_for_1pp_lift": needed,
        "conclusion": interpret(res),
    }
    (OUT / "results.json").write_text(json.dumps(summary, indent=2))
    plot(res, ci_a, ci_b)

    print("=" * 60)
    print("A/B TEST RESULT")
    print("=" * 60)
    print(f"Variant A: {c_a}/{n_a} = {res.rate_a:.2%}  95% CI [{ci_a[0]:.2%}, {ci_a[1]:.2%}]")
    print(f"Variant B: {c_b}/{n_b} = {res.rate_b:.2%}  95% CI [{ci_b[0]:.2%}, {ci_b[1]:.2%}]")
    print(f"Relative lift: {res.rel_lift:+.1%}  95% CI [{res.rel_lift_ci_low:+.1%}, {res.rel_lift_ci_high:+.1%}]")
    print(f"z = {res.z_stat:.3f}, p = {res.p_value:.4f}")
    print(f"Sample-ratio check p = {srm_p:.3f} ({'OK' if srm_p >= 0.001 else 'PROBLEM'})")
    print(f"Users needed per group to detect +1pp at 80% power: {needed}")
    print("-" * 60)
    print(summary["conclusion"])
    print("-" * 60)
    print(f"Saved: {OUT/'results.json'}, {OUT/'ab_test_chart.png'}")


if __name__ == "__main__":
    default = ROOT / "data" / "ab_test_data.csv"
    main(Path(sys.argv[1]) if len(sys.argv) > 1 else default)
