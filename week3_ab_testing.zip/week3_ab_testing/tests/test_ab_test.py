import math
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.ab_test import (sample_size_per_group, srm_check,  # noqa: E402
                         two_proportion_ztest, wilson_ci)


# ---------- normal cases ----------
def test_rates_and_difference_are_computed_correctly():
    r = two_proportion_ztest(100, 1000, 120, 1000)
    assert r.rate_a == pytest.approx(0.10)
    assert r.rate_b == pytest.approx(0.12)
    assert r.abs_diff == pytest.approx(0.02)


def test_clear_winner_is_significant():
    r = two_proportion_ztest(1000, 10000, 1200, 10000)
    assert r.significant
    assert r.p_value < 0.001
    assert r.diff_ci_low > 0  # whole CI above zero


def test_identical_groups_not_significant():
    r = two_proportion_ztest(100, 1000, 100, 1000)
    assert r.p_value == pytest.approx(1.0)
    assert not r.significant
    assert r.diff_ci_low < 0 < r.diff_ci_high  # CI contains zero


def test_ci_contains_point_estimate():
    r = two_proportion_ztest(100, 1000, 130, 1000)
    assert r.diff_ci_low < r.abs_diff < r.diff_ci_high


def test_known_z_value():
    # hand-checked: pooled p=0.11, se=sqrt(.11*.89*(2/1000)) -> z = 0.02/se
    r = two_proportion_ztest(100, 1000, 120, 1000)
    se = math.sqrt(0.11 * 0.89 * 2 / 1000)
    assert r.z_stat == pytest.approx(0.02 / se)


def test_wilson_ci_within_zero_and_one():
    lo, hi = wilson_ci(0, 50)
    assert 0 <= lo <= hi <= 1


def test_sample_size_grows_for_smaller_effect():
    assert sample_size_per_group(0.10, 0.005) > sample_size_per_group(0.10, 0.02)


def test_srm_detects_broken_split():
    assert srm_check(5000, 5050) > 0.001      # normal noise
    assert srm_check(5000, 6000) < 0.001      # clearly broken


# ---------- failure cases ----------
def test_zero_sample_size_raises():
    with pytest.raises(ValueError):
        two_proportion_ztest(0, 0, 10, 100)


def test_conversions_greater_than_users_raises():
    with pytest.raises(ValueError):
        two_proportion_ztest(150, 100, 10, 100)


def test_bad_alpha_raises():
    with pytest.raises(ValueError):
        two_proportion_ztest(10, 100, 12, 100, alpha=1.5)
