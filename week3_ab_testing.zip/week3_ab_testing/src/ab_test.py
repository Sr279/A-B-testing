"""Core statistics for a two-variant (A/B) conversion test.

All functions are small and check one thing, so they are easy to test.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from math import ceil, exp, log, sqrt

from scipy import stats


@dataclass
class ABResult:
    n_a: int
    n_b: int
    conv_a: int
    conv_b: int
    rate_a: float
    rate_b: float
    abs_diff: float          # rate_b - rate_a
    diff_ci_low: float
    diff_ci_high: float
    rel_lift: float          # (rate_b - rate_a) / rate_a
    rel_lift_ci_low: float
    rel_lift_ci_high: float
    z_stat: float
    p_value: float
    alpha: float
    significant: bool

    def to_dict(self) -> dict:
        return asdict(self)


def _validate(conv: int, n: int, name: str) -> None:
    if n <= 0:
        raise ValueError(f"{name}: sample size must be positive, got {n}")
    if conv < 0 or conv > n:
        raise ValueError(f"{name}: conversions must be between 0 and {n}, got {conv}")


def wilson_ci(conv: int, n: int, alpha: float = 0.05) -> tuple[float, float]:
    """Wilson score interval for one proportion (better than the plain Wald CI)."""
    _validate(conv, n, "wilson_ci")
    z = stats.norm.ppf(1 - alpha / 2)
    p = conv / n
    denom = 1 + z**2 / n
    centre = (p + z**2 / (2 * n)) / denom
    half = z * sqrt(p * (1 - p) / n + z**2 / (4 * n**2)) / denom
    return float(centre - half), float(centre + half)


def two_proportion_ztest(conv_a: int, n_a: int, conv_b: int, n_b: int,
                         alpha: float = 0.05) -> ABResult:
    """Two-sided two-proportion z-test + CI for the difference (B - A).

    * p-value uses the POOLED standard error (assumes H0: pA == pB).
    * Confidence interval uses the UNPOOLED standard error (standard practice).
    * Relative-lift CI is obtained with the delta method on log(pB / pA).
    """
    if not 0 < alpha < 1:
        raise ValueError(f"alpha must be in (0, 1), got {alpha}")
    _validate(conv_a, n_a, "variant A")
    _validate(conv_b, n_b, "variant B")

    p_a, p_b = conv_a / n_a, conv_b / n_b
    diff = p_b - p_a

    # --- hypothesis test (pooled) ---
    p_pool = (conv_a + conv_b) / (n_a + n_b)
    se_pool = sqrt(p_pool * (1 - p_pool) * (1 / n_a + 1 / n_b))
    z = diff / se_pool if se_pool > 0 else 0.0
    p_value = float(2 * (1 - stats.norm.cdf(abs(z))))

    # --- confidence interval for difference (unpooled) ---
    z_crit = float(stats.norm.ppf(1 - alpha / 2))
    se_unpooled = sqrt(p_a * (1 - p_a) / n_a + p_b * (1 - p_b) / n_b)
    ci_low, ci_high = diff - z_crit * se_unpooled, diff + z_crit * se_unpooled

    # --- relative lift CI (delta method on log ratio) ---
    if p_a > 0 and p_b > 0:
        se_log = sqrt((1 - p_a) / (n_a * p_a) + (1 - p_b) / (n_b * p_b))
        log_ratio = log(p_b / p_a)
        rel_lift = p_b / p_a - 1
        rl_low = exp(log_ratio - z_crit * se_log) - 1
        rl_high = exp(log_ratio + z_crit * se_log) - 1
    else:
        rel_lift = rl_low = rl_high = float("nan")

    return ABResult(
        n_a=n_a, n_b=n_b, conv_a=conv_a, conv_b=conv_b,
        rate_a=p_a, rate_b=p_b, abs_diff=diff,
        diff_ci_low=ci_low, diff_ci_high=ci_high,
        rel_lift=rel_lift, rel_lift_ci_low=rl_low, rel_lift_ci_high=rl_high,
        z_stat=float(z), p_value=p_value, alpha=alpha, significant=bool(p_value < alpha),
    )


def sample_size_per_group(baseline: float, mde_abs: float,
                          alpha: float = 0.05, power: float = 0.8) -> int:
    """Users needed per variant to detect an absolute lift `mde_abs`."""
    if not 0 < baseline < 1:
        raise ValueError("baseline must be in (0, 1)")
    if mde_abs <= 0 or baseline + mde_abs >= 1:
        raise ValueError("mde_abs must be > 0 and baseline + mde_abs < 1")
    p1, p2 = baseline, baseline + mde_abs
    z_a = stats.norm.ppf(1 - alpha / 2)
    z_b = stats.norm.ppf(power)
    var = p1 * (1 - p1) + p2 * (1 - p2)
    return ceil(((z_a + z_b) ** 2 * var) / (mde_abs ** 2))


def srm_check(n_a: int, n_b: int, expected_ratio: float = 0.5) -> float:
    """Sample Ratio Mismatch: chi-square p-value for the A/B split.

    A very small p-value (< 0.001) means the traffic split is broken and the
    test result should not be trusted.
    """
    total = n_a + n_b
    exp_a, exp_b = total * expected_ratio, total * (1 - expected_ratio)
    chi2 = (n_a - exp_a) ** 2 / exp_a + (n_b - exp_b) ** 2 / exp_b
    return float(1 - stats.chi2.cdf(chi2, df=1))


def interpret(result: ABResult) -> str:
    """Plain-English conclusion."""
    pct = int((1 - result.alpha) * 100)
    lo, hi = result.diff_ci_low * 100, result.diff_ci_high * 100
    d = result.abs_diff * 100
    if result.significant and result.abs_diff > 0:
        verdict = "Variant B is better than A. Recommend rolling out B."
    elif result.significant and result.abs_diff < 0:
        verdict = "Variant B is worse than A. Recommend keeping A."
    else:
        verdict = ("No statistically significant difference. We cannot say B "
                   "beats A; keep A or collect more data.")
    return (
        f"{verdict}\n"
        f"Conversion A = {result.rate_a:.2%}, B = {result.rate_b:.2%}. "
        f"Difference (B - A) = {d:+.2f} percentage points, "
        f"{pct}% CI [{lo:+.2f}, {hi:+.2f}] pp, p = {result.p_value:.4f}."
    )
