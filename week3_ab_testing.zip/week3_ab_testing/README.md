# Week 3: A/B Testing (with confidence intervals)

**Task:** Analyse a sample A/B test and state the conclusion with confidence intervals.

## Project structure
```
week3_ab_testing/
├── README.md               <- you are here
├── REPORT.md               <- full written analysis and conclusion
├── SUBMISSION_NOTE.md      <- short "what I built / what I learned" note
├── requirements.txt
├── analysis.py             <- run this: full analysis + chart + results.json
├── data/
│   ├── generate_data.py    <- creates the sample dataset (seeded)
│   └── ab_test_data.csv    <- sample data (10,000 users)
├── src/
│   └── ab_test.py          <- z-test, CIs, Wilson CI, power, SRM, interpretation
├── tests/
│   └── test_ab_test.py     <- 11 pytest tests (normal + failure cases)
└── outputs/
    ├── ab_test_chart.png
    └── results.json
```

## How to run
```bash
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt

python data/generate_data.py      # optional: regenerate the dataset
python analysis.py                # run the analysis
python -m pytest -v               # run the tests
```
To analyse your own data, use a CSV with columns `user_id, variant (A/B), converted (0/1)`:
```bash
python analysis.py path/to/your_data.csv
```

## Result (summary)
| | A | B |
|---|---|---|
| Conversion | 9.86% | 11.18% |

Difference (B - A) = **+1.32 pp**, **95% CI [+0.12, +2.52] pp**, p = 0.0315
=> B is significantly better. Recommend rolling out B (note the wide interval).

## Hand-in checklist
- [x] Sample A/B test data
- [x] Analysis with conversion rates, z-test, p-value
- [x] Confidence intervals (difference, relative lift, per group)
- [x] Clear written conclusion + caveats (REPORT.md)
- [x] Tests: one normal case, one failure case (and more)
- [x] Short note on what was built and learned
